# Reyana Treders - Final Polished Demo

Run with `npm install` then `npm run dev`.

This package is ready to upload to Vercel via 'Import Project' -> 'Upload'.
