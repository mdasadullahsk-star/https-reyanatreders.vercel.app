
import React, { useState } from 'react';
import { createRoot } from 'react-dom/client';
import { ShoppingCart, Search, User, ArrowDownUp, X, Phone } from 'lucide-react';
import { motion } from 'framer-motion';
import { FcGoogle } from 'react-icons/fc';
import { FaFacebook } from 'react-icons/fa';
import './index.css';

const LOGO_SRC = '/A_logo.png';

export default function App() {
  const [showLogin, setShowLogin] = useState(false);
  const [isSignup, setIsSignup] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [isSorted, setIsSorted] = useState(false);

  // Cart state
  const [cartOpen, setCartOpen] = useState(false);
  const [cartItems, setCartItems] = useState([]); // {id, name, price, qty}

  // Checkout form state
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [checkoutForm, setCheckoutForm] = useState({ name: '', phone: '', address: '' });
  const [showSuccess, setShowSuccess] = useState(false);

  // Contact modal
  const [contactOpen, setContactOpen] = useState(false);
  const [contactForm, setContactForm] = useState({ name: '', email: '', message: '' });
  const [contactSent, setContactSent] = useState(false);

  const products = [
    { id: 1, name: 'Herbal Face Cream', category: 'Cosmetics', price: 249, image: 'https://images.unsplash.com/photo-1585386959984-a41552231693' },
    { id: 2, name: 'Luxury Pen Set', category: 'Stationery', price: 499, image: 'https://images.unsplash.com/photo-1524995997946-a1c2e315a42f' },
    { id: 3, name: 'Organic Rice (1kg)', category: 'Grocery', price: 99, image: 'https://images.unsplash.com/photo-1600087626120-5abf8b7e66d2' },
    { id: 4, name: 'Lipstick Combo Pack', category: 'Cosmetics', price: 399, image: 'https://images.unsplash.com/photo-1585386959984-a41552231693' },
    { id: 5, name: 'A4 Notebook Pack', category: 'Stationery', price: 299, image: 'https://images.unsplash.com/photo-1585306679743-6a30d8f6b8b8' },
    { id: 6, name: 'Fresh Lentils (500g)', category: 'Grocery', price: 79, image: 'https://images.unsplash.com/photo-1590080875831-48c6222b5d2d' },
  ];

  const categories = ['All', 'Cosmetics', 'Stationery', 'Grocery'];

  const filteredProducts = products
    .filter(p => {
      const matchesCategory = selectedCategory === 'All' || p.category === selectedCategory;
      const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    });

  const displayedProducts = isSorted
    ? [...filteredProducts].sort((a, b) => a.price - b.price)
    : filteredProducts;

  // Cart helpers
  const addToCart = (product) => {
    setCartItems(prev => {
      const found = prev.find(i => i.id === product.id);
      if (found) return prev.map(i => i.id === product.id ? { ...i, qty: i.qty + 1 } : i);
      return [...prev, { id: product.id, name: product.name, price: product.price, qty: 1 }];
    });
    setCartOpen(true);
  };

  const changeQty = (id, delta) => {
    setCartItems(prev => prev
      .map(i => i.id === id ? { ...i, qty: Math.max(1, i.qty + delta) } : i)
      .filter(i => i.qty > 0)
    );
  };

  const removeItem = (id) => setCartItems(prev => prev.filter(i => i.id !== id));

  const cartCount = cartItems.reduce((s, it) => s + it.qty, 0);
  const cartTotal = cartItems.reduce((s, it) => s + it.qty * it.price, 0);

  const openCheckout = () => {
    setCheckoutOpen(true);
    setCartOpen(false);
  };

  const placeOrder = () => {
    if (!checkoutForm.name || !checkoutForm.phone || !checkoutForm.address) {
      alert('Please fill name, phone and address to place the order.');
      return;
    }
    setShowSuccess(true);
    setCheckoutOpen(false);
    setCartItems([]);
    setCheckoutForm({ name: '', phone: '', address: '' });
    setTimeout(() => setShowSuccess(false), 4000);
  };

  const sendContact = () => {
    if (!contactForm.name || !contactForm.email || !contactForm.message) {
      alert('Please fill all contact fields');
      return;
    }
    setContactSent(true);
    setContactForm({ name: '', email: '', message: '' });
    setTimeout(() => { setContactSent(false); setContactOpen(false); }, 3000);
  };

  return (
    <div className="min-h-screen bg-green-50 text-gray-800">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 bg-white shadow-sm z-30">
        <div className="max-w-6xl mx-auto flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <img src={LOGO_SRC} alt="Reyana Treders" className="h-10 w-10 object-cover" />
          </div>

          <div className="flex-1 mx-6">
            <div className="max-w-lg mx-auto relative">
              <Search className="absolute left-3 top-3 text-gray-400" size={18} />
              <input value={searchQuery} onChange={(e)=>setSearchQuery(e.target.value)} className="w-full pl-10 pr-4 py-2 border rounded-full" placeholder="Search products..." />
            </div>
          </div>

          <div className="flex items-center gap-4">
            <button onClick={()=>setContactOpen(true)} className="hidden sm:inline-flex items-center gap-2 text-sm text-green-700 border px-3 py-1 rounded-full">
              <Phone size={16}/> Contact
            </button>
            <User size={20} className="cursor-pointer text-gray-600" onClick={()=>setShowLogin(true)} />
            <button onClick={()=>setCartOpen(true)} className="relative flex items-center gap-2 text-gray-700">
              <ShoppingCart size={20}/>
              {cartCount>0 && <span className="ml-1 bg-yellow-400 text-green-800 font-semibold px-2 py-0.5 rounded-full text-sm">{cartCount}</span>}
            </button>
          </div>
        </div>
      </header>

      <div className="pt-20 max-w-6xl mx-auto px-4">
        {/* Hero */}
        <section className="text-center py-8 bg-yellow-50 rounded-lg">
          <motion.h2 initial={{opacity:0,y:8}} animate={{opacity:1,y:0}} className="text-2xl font-semibold text-green-700">Shop Cosmetics, Stationery & Grocery — Reyana Treders</motion.h2>
          <p className="text-gray-600 mt-1">Quality you trust. Prices you'll love.</p>
        </section>

        {/* Category Tabs */}
        <div className="flex items-center gap-3 mt-6 flex-wrap">
          {categories.map(cat=>(
            <button key={cat} onClick={()=>setSelectedCategory(cat)} className={`px-4 py-2 rounded-full text-sm ${selectedCategory===cat ? 'bg-green-600 text-white' : 'bg-white border text-green-700'}`}>{cat}</button>
          ))}
        </div>

        {/* Sort */}
        <div className="flex justify-end mt-4">
          <button onClick={()=>setIsSorted(!isSorted)} className="flex items-center gap-2 bg-green-600 text-white px-3 py-2 rounded-full text-sm"><ArrowDownUp size={16}/> Sort by Price {isSorted && '(Low → High)'}</button>
        </div>

        {/* Grid */}
        <main className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 mt-6">
          {displayedProducts.length>0 ? displayedProducts.map(p=>(
            <motion.div key={p.id} whileHover={{y:-6}} className="bg-white rounded-lg shadow-sm overflow-hidden">
              <img src={p.image} alt={p.name} className="h-44 w-full object-cover"/>
              <div className="p-4">
                <h3 className="font-semibold text-lg">{p.name}</h3>
                <p className="text-sm text-gray-500">{p.category}</p>
                <div className="flex items-center justify-between mt-3">
                  <span className="font-bold text-green-700">₹{p.price}</span>
                  <div className="flex items-center gap-2">
                    <button onClick={()=>changeQty(p.id,-1)} className="px-2 py-1 rounded-full border">-</button>
                    <span className="px-2">1</span>
                    <button onClick={()=>changeQty(p.id,1)} className="px-2 py-1 rounded-full border">+</button>
                    <button onClick={()=>addToCart(p)} className="bg-green-600 text-white px-3 py-1 rounded-full">Add</button>
                  </div>
                </div>
              </div>
            </motion.div>
          )) : <p className="col-span-full text-center text-gray-500">No products found.</p>}
        </main>
      </div>

      {/* Side Cart */}
      <div className={`fixed top-0 right-0 h-full w-full sm:w-96 bg-white shadow-xl transform transition-transform z-40 ${cartOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="p-4 flex items-center justify-between border-b">
          <h3 className="text-lg font-semibold">Your Cart</h3>
          <button onClick={()=>setCartOpen(false)}><X/></button>
        </div>
        <div className="p-4 overflow-auto" style={{height:'calc(100% - 160px)'}}>
          {cartItems.length===0 ? <p className="text-gray-500 mt-6">Your cart is empty.</p> : cartItems.map(item=>(
            <div key={item.id} className="flex items-center gap-3 mb-4">
              <div className="flex-1">
                <h4 className="font-medium">{item.name}</h4>
                <p className="text-sm text-gray-500">₹{item.price} each</p>
                <div className="flex items-center gap-2 mt-2">
                  <button onClick={()=>changeQty(item.id,-1)} className="px-2 py-1 rounded-full border">-</button>
                    <span className="px-3">{item.qty}</span>
                    <button onClick={()=>changeQty(item.id,1)} className="px-2 py-1 rounded-full border">+</button>
                    <button onClick={()=>removeItem(item.id)} className="ml-2 text-sm text-red-500">Remove</button>
                </div>
              </div>
              <div className="text-right font-semibold">₹{item.price*item.qty}</div>
            </div>
          ))}
        </div>
        <div className="p-4 border-t">
          <div className="flex items-center justify-between mb-3"><span className="font-medium">Total</span><span className="font-bold">₹{cartTotal}</span></div>
          <button onClick={openCheckout} disabled={cartItems.length===0} className={`w-full py-2 rounded-lg ${cartItems.length===0 ? 'bg-gray-300' : 'bg-green-600 text-white'}`}>Proceed to Checkout (COD)</button>
        </div>
      </div>

      {/* Checkout Modal */}
      {checkoutOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-lg p-6 w-96">
            <div className="flex items-center gap-3 mb-4">
              <img src={LOGO_SRC} alt="logo" className="h-10 w-10 object-cover"/>
              <h2 className="text-xl font-bold text-green-700">Checkout</h2>
            </div>
            <input value={checkoutForm.name} onChange={(e)=>setCheckoutForm({...checkoutForm,name:e.target.value})} placeholder="Full Name" className="w-full mb-3 p-2 border rounded-lg"/>
            <input value={checkoutForm.phone} onChange={(e)=>setCheckoutForm({...checkoutForm,phone:e.target.value})} placeholder="Phone Number" className="w-full mb-3 p-2 border rounded-lg"/>
            <textarea value={checkoutForm.address} onChange={(e)=>setCheckoutForm({...checkoutForm,address:e.target.value})} placeholder="Delivery Address" className="w-full mb-3 p-2 border rounded-lg" rows={3}/>
            <div className="flex items-center justify-between mb-4"><span className="font-medium">Payment</span><span className="text-sm text-gray-600">Cash on Delivery</span></div>
            <div className="flex items-center gap-2">
              <button onClick={placeOrder} className="bg-green-600 text-white w-full py-2 rounded-lg">Place Order (COD)</button>
              <button onClick={()=>setCheckoutOpen(false)} className="py-2 px-3 rounded-lg border">Cancel</button>
            </div>
          </div>
        </div>
      )}

      {/* Contact Modal */}
      {contactOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-lg p-6 w-96">
            <h2 className="text-xl font-bold text-green-700 mb-3">Contact Us</h2>
            <input value={contactForm.name} onChange={(e)=>setContactForm({...contactForm,name:e.target.value})} placeholder="Full Name" className="w-full mb-3 p-2 border rounded-lg"/>
            <input value={contactForm.email} onChange={(e)=>setContactForm({...contactForm,email:e.target.value})} placeholder="Email" className="w-full mb-3 p-2 border rounded-lg"/>
            <textarea value={contactForm.message} onChange={(e)=>setContactForm({...contactForm,message:e.target.value})} placeholder="Message" className="w-full mb-3 p-2 border rounded-lg" rows={4}/>
            <div className="flex items-center gap-2">
              <button onClick={sendContact} className="bg-green-600 text-white py-2 px-4 rounded-lg">Send Message</button>
              <button onClick={()=>setContactOpen(false)} className="py-2 px-4 rounded-lg border">Cancel</button>
            </div>
            {contactSent && <p className="mt-3 text-green-600">💌 Message sent successfully! We'll get back to you soon.</p>}
          </div>
        </div>
      )}

      {/* Login Modal */}
      {showLogin && (
        <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-lg p-6 w-80 text-center">
            <h2 className="text-xl font-bold text-green-700 mb-4">{isSignup ? 'Create Account' : 'Login to Reyana Treders'}</h2>
            {isSignup && <input type="text" placeholder="Full Name" className="w-full mb-3 p-2 border rounded-lg" />}
            <input type="email" placeholder="Email" className="w-full mb-3 p-2 border rounded-lg" />
            {isSignup && <input type="tel" placeholder="Mobile Number" className="w-full mb-3 p-2 border rounded-lg" />}
            <input type="password" placeholder="Password" className="w-full mb-4 p-2 border rounded-lg" />
            <button className="bg-green-600 text-white w-full py-2 rounded-lg">{isSignup ? 'Sign Up' : 'Login'}</button>
            <div className="my-4 border-t border-gray-200"></div>
            <p className="text-sm text-gray-600 mb-2">Or continue with</p>
            <div className="flex justify-center gap-4">
              <button className="flex items-center gap-2 border px-3 py-1 rounded-lg hover:bg-gray-100"><FcGoogle size={20} /> Google</button>
              <button className="flex items-center gap-2 border px-3 py-1 rounded-lg hover:bg-gray-100 text-blue-600"><FaFacebook size={20} /> Facebook</button>
            </div>
            <p className="text-sm text-gray-500 mt-4">
              {isSignup ? 'Already have an account?' : `Don't have an account?`}{' '}
              <span className="text-green-600 cursor-pointer" onClick={()=>setIsSignup(!isSignup)}>{isSignup ? 'Login' : 'Sign Up'}</span>
            </p>
            <button onClick={()=>setShowLogin(false)} className="mt-4 text-gray-500 hover:text-red-500">Close</button>
          </div>
        </div>
      )}

      {/* Success Toast */}
      {showSuccess && <div className="fixed bottom-6 right-6 bg-green-600 text-white px-4 py-3 rounded-lg shadow-lg z-50">🛍️ Order placed successfully! Thank you for shopping with Reyana Treders.</div>}
    </div>
  );
}

// Render
const rootEl = document.getElementById('root');
if (rootEl) {
  createRoot(rootEl).render(<App />);
}
